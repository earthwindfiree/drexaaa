# Crypgo Design Tokens & Homepage Map

Source of truth: `nextjs/Crypgo-nextjs-tailwind-main/package/src/app/globals.css`. The source uses **Tailwind CSS v4** theme directives and CSS custom properties, with shadcn-style semantic tokens. Verify exact usage in the source before porting.

## Typography
- Font family: **DM Sans**, loaded through `next/font/google` in `src/app/layout.tsx`.
- Preserve a clear display-heading/body-text hierarchy and responsive line lengths when adapting.

## Core theme variables
The file defines semantic CSS variables in `:root` and `.dark`. Key values found in the supplied source:

| Token | Source value | Intended role |
|---|---|---|
| `--radius` | `0.625rem` | Base corner radius |
| `--background` | `oklch(11.359% 0.03282 250.77)` | Dark blue-toned page background |
| `--foreground` | `#263238` | Foreground semantic token (check source usage; the value appears atypical against the dark background) |
| `--primary` | `oklch(84.972% 0.12016 146.073)` | Bright green primary accent |
| `--secondary` | `oklch(75.768% 0.125 198.173)` | Cyan/teal secondary accent |
| `--muted` | `oklch(88.911% 0.00329 198.79)` | Muted surfaces/text semantics |
| `--border` | `oklch(100% 0.00011 271.152 / 0.102)` | Low-opacity light border |
| `--tealGreen` | `#477e70` | Custom teal-green |
| `--charcoalGray` | `#666c78` | Custom charcoal gray |
| `--shadow-cause-shadow` | `0px 4px 17px 0px #00000008` | Very subtle shadow |

Other defined theme tokens include `--card`, `--popover`, `--accent`, `--destructive`, `--input`, `--ring`, `--chart-1` through `--chart-5`, and sidebar semantic tokens. The stylesheet also defines custom spacing, z-index, blur, transition, and background-image theme values. Read the original CSS for the complete definitions.

## Tailwind v4 theme mappings
The source maps semantic variables to Tailwind theme names, including:
- `--color-background`, `--color-foreground`
- `--color-primary`, `--color-primary-foreground`
- `--color-secondary`, `--color-secondary-foreground`
- `--color-muted`, `--color-muted-foreground`
- `--color-accent`, `--color-border`, `--color-input`, `--color-ring`
- `--color-tealGreen`, `--color-charcoalGray`
- `--radius-sm` through `--radius-4xl`

The stylesheet uses `@import 'tailwindcss'`, `@import "tw-animate-css"`, `@import "shadcn/tailwind.css"`, `@theme`, and `@theme inline`.

## Homepage section order
Source: `nextjs/Crypgo-nextjs-tailwind-main/package/src/app/page.tsx`

1. `Hero`
2. `Work`
3. `GlobalReach`
4. `TimeLine`
5. `Platform`
6. `Portfolio`
7. `Upgrade`
8. `Perks`
9. `Faq`

Find implementations under `nextjs/Crypgo-nextjs-tailwind-main/package/src/components/Home/`. The shared header/footer and theme provider are wired in `src/app/layout.tsx`.

## Asset guidance
- Assets are under `nextjs/Crypgo-nextjs-tailwind-main/package/public/images/`.
- Keep asset paths and licenses/attribution requirements in mind; do not assume assets should be copied unchanged into another product.
- Prefer adapting layout, spacing, colors, typography, card treatments, button treatments, and responsive behavior rather than copying unrelated crypto content.

## Token porting checklist
- [ ] Identify the target project's existing CSS variables/theme tokens.
- [ ] Map semantic roles (background, text, surface, primary, secondary, border, muted, focus ring) rather than blindly copying variable names.
- [ ] Preserve accessible text contrast in both light and dark modes.
- [ ] Reuse existing spacing/radius conventions where practical; add only necessary tokens.
- [ ] Keep the target app's existing font unless a deliberate typography change is approved.
- [ ] Test mobile, tablet, and desktop breakpoints.
- [ ] Check keyboard focus, hover, reduced-motion behavior, and contrast.
