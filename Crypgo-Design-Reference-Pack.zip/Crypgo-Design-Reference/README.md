# Crypgo Homepage Design Reference Pack

This folder contains the extracted source reference from the supplied **Crypgo - Shadcn UI Crypto Landing Page Template** archive, organized for use by a coding AI when redesigning another site's homepage.

## Start here

1. Read `DESIGN-TOKENS.md` first.
2. Use the **Next.js reference** as the primary source for tokens and homepage implementation:
   - `nextjs/Crypgo-nextjs-tailwind-main/package/src/app/globals.css` — global design tokens, theme variables, custom spacing, shadows, and CSS utilities.
   - `nextjs/Crypgo-nextjs-tailwind-main/package/src/app/layout.tsx` — DM Sans font and app shell/theme provider.
   - `nextjs/Crypgo-nextjs-tailwind-main/package/src/app/page.tsx` — homepage section order.
   - `nextjs/Crypgo-nextjs-tailwind-main/package/src/components/Home/` — individual homepage sections.
   - `nextjs/Crypgo-nextjs-tailwind-main/package/public/images/` — original image and illustration assets.
3. Use `astro/` only as a secondary implementation reference; it is a separate version of the template.

## Important integration rule

Treat this as a **visual/design reference**, not a replacement app. Do not copy the entire template over the target project. Inspect the target repository and preserve its framework, routing, business logic, APIs, authentication, existing design conventions outside the requested homepage, and uncommitted work. Port only the relevant homepage layout, visual styling, reusable components, and assets.

## Suggested coding-AI workflow

- Inspect the target repository and report its framework, current homepage entry point, styling system, shared layout, and working-tree state before editing.
- Map the Crypgo homepage sections to the target site's homepage and identify what is appropriate to reuse, adapt, omit, or replace.
- Extract the design tokens into the target project's existing token system rather than introducing a competing global theme.
- Recreate the look responsively; adapt text, links, data, and calls to action to the target product.
- Avoid copying Crypgo branding or crypto-specific claims/content unless the target product genuinely needs them.
- Do not overwrite unrelated files or install packages without explaining why and checking the target stack.
- Run the project's available lint, type-check, tests, and build commands; report any failures honestly.
